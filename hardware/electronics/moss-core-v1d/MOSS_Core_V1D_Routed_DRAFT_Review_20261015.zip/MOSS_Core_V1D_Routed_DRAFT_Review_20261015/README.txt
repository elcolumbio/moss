MOSS Core V1D - working design review
2026-10-15
NOT FOR FABRICATION OR ASSEMBLY ORDER

The V1C package must not be fabricated: U10/U11 contained an incorrect physical
second-gate pin assignment. See V1C_CRITICAL_ERRATA.txt. A clean ERC or DRC did
not detect that incorrect custom-symbol contract. V1D is published as a routed
DRAFT for review. The V1C archive is retained for traceability. Neither package
is approved for fabrication. This package has not been submitted to PCBWay.

Current deliverables
- Integrated_Design/MOSS_Core_V1D_DRAFT.kicad_sch: editable complete schematic.
- Integrated_Design/MOSS_Core_V1D_DRAFT.kicad_pcb: editable working PCB.
  See Integrated_Design/PCB_WORKING_STATUS.json for current routing status.
- Integrated_Design/MOSS_Core_V1D_DRAFT_Schematic.pdf: schematic review export.
- Local symbols, footprints and available 3D models accompany the native design.
  The missing J5 model does not establish physical cable fit.
- Integrated_Design/PCB_Review_Top.png and PCB_Review_Bottom.png: review views.
- Integrated_Design/PCB_3D_preview.png: native perspective preview; see
  3D_PREVIEW_NOTES.json for absent models and simplified component envelopes.
- CONNECTOR_GUIDE.txt: English connector roles, pin numbering and power limits.
- BOM_WORKING_NOT_FOR_ORDER.csv: 254 assembled components in 102 grouped lines.
- reviews/: primary-source pin audits, bounded logic evidence and remaining limits.
- firmware/: English porting contract and constants, NOT operational firmware.
- Audio_Stage/: earlier audio-only subcircuit; Integrated_Design is the full design.

Implemented in the working schematic
1. Hardware-controlled separate motor and servo supply switches, downstream
   voltage measurement, sticky rail-loss faults and explicit re-arm behavior.
2. Native three-pin powered servo output with half-duplex data buffers and
   switched idle bias. One existing daisy chain is retained.
3. Integrated MAX98357A mono amplifier, PH2 speaker connector and separately
   fused battery-to-audio supply. Speaker confirmed by user: 4 ohm, 3 W.
4. All four Cytron PWM/DIR inputs are inhibited when motor power is invalid.
5. I2C status readback at 0x41; no boot-strapping GPIO is reassigned.
6. External USB hub retained. Core is one peripheral alongside one depth camera,
   wrist camera, LiDAR and Xbox receiver. Host power converter remains separate.

Static evidence and its limits
The delivered PCB is fully routed. Final native DRC reports zero violations,
zero missing connections and zero schematic/PCB parity issues. The independent
review preserves all 531 retained critical copper items and all component/pad
geometry. See Integrated_Design/Final_Review for the exact board hashes, native
default ignored checks, geometric review flags and scope limits.

The integrated schematic has 266 footprints, including four corner holes
and eight test pads. Recorded pre-routing checks reported 780 connected physical
pins with zero net mismatches, and native ERC reported zero errors/warnings
under its recorded rules. These historical reports retain their original scope.
128 motor-signal cases and 107 interlock events pass the bounded models. Primary
package pin tables were checked separately from the original symbol contracts.
These checks are not hardware, thermal, USB compliance or firmware validation.

Working mechanical envelope
80 x 85 mm, four M2.5 holes (2.7 mm drill) at (4,4), (76,4), (4,81), (76,81).
Each hole retains an 8 mm diameter tool/copper reservation. The printed carrier
must follow the finished PCB. This envelope is not yet proven to fit the rover.

Prototype assumptions, not user-confirmed performance guarantees
The native servo feed is limited to about 2.5 A nominal for the existing chain
and nominal 3 A connector. The motor branch is about 8.1 A nominal in total,
not 10 A per motor. Exact corners are in POWER_STAGE_EVIDENCE.json. The arm's
simultaneous load capability and motor starting current require measurement.
Both actuator rails are cut on the global hardware stop; the host remains on
its existing supply. A normal drive stop must not silently remove arm holding
torque; the firmware contract distinguishes these actions.

Geometric review flags remain pending; routing completion does not waive
the findings in FINAL_ROUTED_GEOMETRY.json.

Before manufacturing prototypes
- Review the documented return/decoupling findings, power-current/thermal
  assumptions and fabrication stackup. Clean static checks are not hardware
  qualification or a manufacturing approval.
- Physical connector mating/pin polarity, service access and rover clearance.
- PCBWay stock, approved substitutions and controlled-impedance stackup/quote.

Before powered actuator testing and hardware qualification
- Full-pack/BMS acceptance of motor and servo regeneration. The single-FET
  branches retain a reverse path, but neither that path nor the input TVS
  guarantees the servo rail stays below 12.6 V. A bounded energy-sink strategy
  or verified battery behavior is required before powered motion tests.
- Real Cytron/servo input capacitance and startup load versus the timer/SOA
  envelope; FET case-temperature assumption, short transients and wire ratings.
- Audio output limiting and buck compensation with DC-biased MLCC values.
- Firmware implementation and USB boot/suspend/audio/servo integration tests.

No Gerbers, assembly-placement order file, order submission or payment are
provided as an approved manufacturing release. Planned quantity remains TWO
assembled prototypes after the relevant design/release checks.

Public package provenance
This is a publication copy of the 2026-10-15 local review snapshot.
The PCB, schematic, libraries and technical evidence are unchanged.
Local editor lock files were omitted; publication statements in the
README, erratum and routing notes were updated. The package manifest
was regenerated. Historical reports may retain local provenance paths
and earlier routing states; PCB_WORKING_STATUS.json identifies the
delivered routed board. Publication is not manufacturing approval.
