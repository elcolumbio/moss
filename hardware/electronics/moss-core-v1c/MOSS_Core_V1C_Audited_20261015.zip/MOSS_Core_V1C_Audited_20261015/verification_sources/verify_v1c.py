#!/usr/bin/env python3
"""Read-only static review of MOSS V1C. Prints JSON; never modifies design files.

Usage: python verify_v1c.py /path/netlist.xml [--circuit /path/circuit.json]
The logic simulation follows the exported physical pin/net graph. Gate pin
functions below are independently transcribed from manufacturer datasheets.
It does NOT execute the firmware or simulate analogue voltages/timing.
"""
import argparse
import copy
import hashlib
import itertools
import json
import math
import re
import sys
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path

SOURCES = {
    'HCS21': 'https://www.ti.com/lit/ds/symlink/sn74hcs21.pdf',
    'LVC1G17': 'https://www.ti.com/lit/ds/symlink/sn74lvc1g17.pdf',
    'LVC74': 'https://www.ti.com/lit/ds/symlink/sn74lvc74a.pdf',
    'LVC2G08': 'https://www.ti.com/lit/ds/symlink/sn74lvc2g08.pdf',
    'LVC1G08': 'https://www.ti.com/lit/ds/symlink/sn74lvc1g08.pdf',
    'LVC1G126': 'https://www.ti.com/lit/ds/symlink/sn74lvc1g126.pdf',
    'TPS3431': 'https://www.ti.com/lit/ds/symlink/tps3431.pdf',
    'TLV62569': 'https://www.ti.com/lit/ds/symlink/tlv62569.pdf',
    'TLV803E': 'https://www.ti.com/lit/ds/symlink/tlv803e.pdf',
    'TPS2553': 'https://www.ti.com/lit/ds/symlink/tps2553.pdf',
    'TPS22918': 'https://www.ti.com/lit/ds/symlink/tps22918.pdf',
}

def require(condition, message):
    if not condition:
        raise AssertionError(message)

def scalar(value):
    m = re.fullmatch(r'([0-9]+(?:\.[0-9]+)?)([munpMk]?)(?:F|H|ohm)?', value)
    require(m is not None, f'Unsupported numeric value {value!r}')
    return float(m.group(1)) * {'': 1, 'm': 1e-3, 'u': 1e-6, 'n': 1e-9,
                               'p': 1e-12, 'k': 1e3, 'M': 1e6}[m.group(2)]

class Review:
    def __init__(self, circuit, root):
        self.parts = {p['ref']: p for p in circuit['parts']}
        require(len(self.parts) == len(circuit['parts']), 'Duplicate references')
        self.net = {}
        self.members = defaultdict(set)
        self.xml_parts = {}
        for component in root.findall('./components/comp'):
            self.xml_parts[component.attrib['ref']] = component
        for net in root.findall('./nets/net'):
            for node in net.findall('node'):
                key = node.attrib['ref'], node.attrib['pin']
                require(key not in self.net, f'Native pin appears in multiple nets: {key}')
                self.net[key] = net.attrib['name']
                self.members[net.attrib['name']].add(key)
        self.requirements = []

    def pin(self, ref, pin):
        return self.net[(ref, str(pin))]

    def expect(self, ref, pin, net):
        require(self.pin(ref, pin) == net,
                f'{ref}.{pin}: expected {net}, got {self.pin(ref, pin)}')

    def resistor(self, ref, a, b, value=None):
        require(self.parts[ref]['kind'] == 'R', f'{ref} is not a resistor')
        require({self.pin(ref, 1), self.pin(ref, 2)} == {a, b}, f'{ref} wrong nodes')
        if value is not None:
            require(math.isclose(scalar(self.parts[ref]['value']), value), f'{ref} wrong value')

    def compare_netlist(self):
        expected = set()
        for ref, p in self.parts.items():
            # Zero-pin mounting holes may be exported as components but are not electrical.
            require(ref in self.xml_parts, f'Component missing from XML: {ref}')
            actual_value = self.xml_parts[ref].findtext('value')
            require(actual_value == p['value'], f'{ref} value mismatch {actual_value!r}')
            actual_fp = self.xml_parts[ref].findtext('footprint')
            require(actual_fp == p.get('fp_local', p['fp']), f'{ref} footprint mismatch')
            for pn, (name, net, kind) in p['pins'].items():
                key = ref, pn
                expected.add(key)
                require(key in self.net, f'Pin missing from XML: {key}')
                if net is None:
                    require(self.net[key].startswith('unconnected-'), f'{key} expected NC')
                    require(self.members[self.net[key]] == {key}, f'{key} NC unexpectedly joined')
                else:
                    require(self.net[key] == net, f'{key}: JSON {net}, XML {self.net[key]}')
        require(expected == set(self.net), f'Unexpected XML pins: {set(self.net)-expected}')
        require(set(self.xml_parts) == set(self.parts), 'Unexpected/missing native component')
        return len(expected)

    def structural(self):
        # Actual module pin numbers, not signal names or GPIO number assumptions.
        for pin, net in {13:'ESP_USB_N', 14:'ESP_USB_P', 35:'ENC_POWER_EN',
                         36:'ARMED_DRIVE', 37:'DEBUG_TX', 38:'USB_PWR_FAULT_N',
                         39:'ARMED_ACT'}.items():
            self.expect('U1', pin, net)
        self.expect('U9', 5, self.pin('U1', 36))
        self.expect('U9', 9, self.pin('U1', 39))
        require(self.parts['U1']['mpn'] == 'ESP32-S3-WROOM-1U-N8', 'Wrong module variant')
        require(self.parts['U1']['pins']['36'][2] == 'input', 'Latch feedback must be an input')
        require(self.parts['U1']['pins']['39'][2] == 'input', 'Latch feedback must be an input')
        self.requirements.append('Physical latch feedback and native USB pin map')

        for ref, mpn, pins in [
            ('U3','TPS2553DBVR',{1:'V5_PRE',2:'GND',3:'V5_PRE',4:'USB_PWR_FAULT_N',5:'USB_ILIM',6:'V5'}),
            ('U4','TLV62569DBVR',{1:'BUCK_EN',2:'GND',3:'BUCK_SW',4:'V5',5:'BUCK_FB'}),
            ('U20','TLV803EA30DBZR',{1:'GND',2:'RESET_N',3:'3V3'}),
            ('U22','TPS22918DBVR',{1:'3V3',2:'GND',3:'ENC_POWER_EN',4:'ENC_SLEW_CT',5:'ENC_3V3',6:'ENC_3V3'}),
        ]:
            require(self.parts[ref]['mpn'] == mpn, f'{ref} unexpected device: re-review pinmap')
            for pin, net in pins.items(): self.expect(ref, pin, net)
        self.resistor('R5','3V3','RESET_N',10000)
        self.resistor('R75','ENC_POWER_EN','GND',47000)
        require(not any(p['kind']=='C' and {self.pin(p['ref'],1),self.pin(p['ref'],2)}=={'RESET_N','GND'}
                        and scalar(p['value'])>1e-7 for p in self.parts.values()),
                'Old large reset capacitor remains')
        for j in ['J3','J4']: self.expect(j,2,'ENC_3V3')
        for net in ['EL_A_F','EL_B_F','ER_A_F','ER_B_F']:
            resistors = [p for p in self.parts.values() if p['kind']=='R' and net in {v[1] for v in p['pins'].values()}]
            require(any({self.pin(p['ref'],1),self.pin(p['ref'],2)}=={net,'ENC_3V3'}
                        and scalar(p['value'])==10000 for p in resistors), f'{net} lacks switched pullup')
            require(any({self.pin(p['ref'],1),self.pin(p['ref'],2)}=={net,'GND'}
                        and scalar(p['value'])==100000 for p in resistors), f'{net} lacks off-state pulldown')
            require(not any('3V3' in {v[1] for v in p['pins'].values()} for p in resistors),
                    f'{net} still back-pulled from always-on rail')
        self.requirements.append('New power IC physical pinmaps, reset supervision and switched encoder pullups')

        for pin in self.parts['U1']['pins']:
            require(self.pin('U1',pin) not in {'AMP_5V','AUDIO_5V_SENSE'}, 'External amplifier rail reaches MCU')
        # Search resistor-only paths, which catches a divider renamed to another net.
        graph=defaultdict(set)
        for p in self.parts.values():
            if p['kind']=='R':
                a,b=self.pin(p['ref'],1),self.pin(p['ref'],2)
                if a not in {'GND','3V3','V5'} and b not in {'GND','3V3','V5'}:
                    graph[a].add(b);graph[b].add(a)
        visited={'AMP_5V'};pending=['AMP_5V']
        while pending:
            node=pending.pop()
            for neighbor in graph[node]-visited:visited.add(neighbor);pending.append(neighbor)
        require(not visited.intersection({self.pin('U1',p) for p in self.parts['U1']['pins']}),
                'Resistive external AMP rail path still reaches MCU')
        self.requirements.append('No resistive AMP_5V-to-MCU path')

        require(self.parts['U14']['mpn']=='SN74LVC1G126DCKR', 'Servo buffer not audited LVC part')
        for pin,net in {1:'SERVO_OE_ON',2:'SERVO_TX',3:'GND',4:'SERVO_TX_BUF',5:'3V3'}.items():self.expect('U14',pin,net)
        self.resistor('R44','SERVO_OE_ON','GND',10000)
        self.resistor('R93','SERVO_TX','3V3',47000)
        self.resistor('R48','SERVO_TX_BUF','SERVO_BUS',47)
        self.resistor('R53','A_EN_BUF','AMP_ENABLE',2200)
        for ref,net in [('R90','AUDIO_BCLK'),('R91','AUDIO_LRCLK'),('R92','AUDIO_DATA')]:self.resistor(ref,net,'GND',47000)
        self.requirements.append('3V3 servo TX, OE default off, I2S reset pulldowns and SD_MODE series protection')

        self.expect('U5',7,self.pin('U5',8))
        self.expect('U5',5,'3V3')
        self.resistor('R10','3V3','WD_TIME',10000)
        require(scalar(self.parts['R11']['value']) >= 10000, 'Watchdog pullup excessive in suspend')
        self.expect('U9',1,'SAFE_CLR_N');self.expect('U9',13,'SAFE_CLR_N')
        for pin in (2,4,10,12):self.expect('U9',pin,'3V3')
        self.requirements.append('Watchdog ENOUT wiring and asynchronous fault-clear topology')

    def gate_list(self):
        # (MPN, outputs: [(physical output pin, op, input pins)])
        specs = {
            'U6':('SN74HCS21PWR',[(6,'AND',(1,2,4,5)),(8,'AND',(9,10,12,13))]),
            'U18':('SN74LVC1G17DCKR',[(4,'BUF',(2,))]),
            'U10':('SN74LVC2G08DCUR',[(7,'AND',(1,2)),(6,'AND',(3,5))]),
            'U11':('SN74LVC2G08DCUR',[(7,'AND',(1,2)),(6,'AND',(3,5))]),
            'U13':('SN74LVC1G08DCKR',[(4,'AND',(1,2))]),
            'U14':('SN74LVC1G126DCKR',[(4,'BUF_EN',(1,2))]),
        }
        gates=[]
        for ref,(mpn,models) in specs.items():
            require(self.parts[ref]['mpn']==mpn,f'{ref}: no verified physical model for current part')
            for out,op,ins in models:gates.append((self.pin(ref,out),op,tuple(self.pin(ref,p) for p in ins)))
        return gates

    def simulate(self, initial, previous_q, previous_clock, mutate=None):
        netmap = self.net
        if mutate:
            self.net=copy.copy(self.net);self.net[mutate[0]]=mutate[1]
        try:
            gates=self.gate_list()
            dff=[(self.pin('U9',cl),self.pin('U9',d),self.pin('U9',clk),self.pin('U9',pr),self.pin('U9',q))
                 for cl,d,clk,pr,q in [(1,2,3,4,5),(13,12,11,10,9)]]
        finally:self.net=netmap
        v={'3V3':1,'GND':0,**initial}
        for ff,q in zip(dff,previous_q):v[ff[4]]=q
        def settle():
            for _ in range(12):
                changed=False
                for out,op,ins in gates:
                    if not all(n in v for n in ins):continue
                    x=[v[n] for n in ins]
                    y=int(all(x)) if op=='AND' else x[0] if op=='BUF' else x[1] if x[0] else 'Z'
                    if v.get(out)!=y:v[out]=y;changed=True
                if not changed:return
            raise AssertionError('Combinational model failed to settle')
        settle()
        for i,(cl,d,clk,pr,q) in enumerate(dff):
            require(v[pr]==1,'Preset not inactive')
            if v[cl]==0:v[q]=0
            elif not previous_clock[i] and v[clk]:v[q]=v[d]
        settle()
        return v

    def logic_tests(self):
        cases=0
        for health in itertools.product((0,1),repeat=4):
            for q in itertools.product((0,1),repeat=2):
                for prev in itertools.product((0,1),repeat=2):
                    for req in itertools.product((0,1),repeat=2):
                        for pwm in itertools.product((0,1),repeat=2):
                            for txen,txdata in itertools.product((0,1),repeat=2):
                                inputs=dict(zip(('WD_OK','NC_FILTER','FAULT_FILTER_N','RESET_N'),health))
                                inputs.update(DRIVE_ENABLE=req[0],ACTUATOR_REQUEST=req[1],PWM_L=pwm[0],PWM_R=pwm[1],SERVO_TX_ENABLE=txen,SERVO_TX=txdata)
                                got=self.simulate(inputs,q,prev)
                                # Independent system requirements, not pin-to-pin self comparisons.
                                expected_q=tuple(0 if not all(health) else 1 if req[i] and not prev[i] else q[i] for i in range(2))
                                motor=expected_q[0] and req[0];act=expected_q[1] and req[1]
                                require(got['ARMED_DRIVE']==expected_q[0] and got['ARMED_ACT']==expected_q[1],'Latch equation mismatch')
                                require(got['PWM_L_SAFE']==int(pwm[0] and motor),'Left PWM escaped inhibit')
                                require(got['PWM_R_SAFE']==int(pwm[1] and motor),'Right PWM escaped inhibit')
                                require(got['ACT_PERMIT']==int(act),'Actuator permission mismatch')
                                require(got['SERVO_TX_BUF']==(txdata if txen and act else 'Z'),'TX escaped inhibit')
                                cases+=1
        sequences=0
        for fault in ('WD_OK','NC_FILTER','FAULT_FILTER_N','RESET_N'):
            base=dict(WD_OK=1,NC_FILTER=1,FAULT_FILTER_N=1,RESET_N=1,
                      DRIVE_ENABLE=1,ACTUATOR_REQUEST=1,PWM_L=1,PWM_R=1,SERVO_TX_ENABLE=1,SERVO_TX=1)
            a=self.simulate(base,(0,0),(0,0))
            require((a['ARMED_DRIVE'],a['ARMED_ACT'])==(1,1),'Could not arm')
            b=self.simulate({**base,fault:0},(1,1),(1,1))
            c=self.simulate(base,(b['ARMED_DRIVE'],b['ARMED_ACT']),(1,1))
            require((c['PWM_L_SAFE'],c['PWM_R_SAFE'],c['ACT_PERMIT'])==(0,0,0),'Fault recovery auto-rearmed')
            d=self.simulate({**base,'DRIVE_ENABLE':0,'ACTUATOR_REQUEST':0},(0,0),(1,1))
            e=self.simulate(base,(d['ARMED_DRIVE'],d['ARMED_ACT']),(0,0))
            require((e['ARMED_DRIVE'],e['ARMED_ACT'])==(1,1),'Fresh edge failed')
            sequences+=1
        # Sensitivity: changing a real physical gate pin must affect the model.
        base=dict(WD_OK=0,NC_FILTER=1,FAULT_FILTER_N=1,RESET_N=1,
                  DRIVE_ENABLE=1,ACTUATOR_REQUEST=1,PWM_L=1,PWM_R=1,SERVO_TX_ENABLE=1,SERVO_TX=1)
        broken=self.simulate(base,(1,1),(1,1),mutate=(('U6','1'),'3V3'))
        require(broken['PWM_L_SAFE']==1,'Mutation test failed to detect bypassed watchdog')
        return {'exhaustive_combinations':cases,'fault_recovery_sequences':sequences,
                'physical_pin_mutation_sensitivity_checks':1,
                'scope':'Actual native pin/net graph and datasheet logic at valid, stable power; no timing, metastability, analogue power ramps or firmware execution.'}

    def calculations(self):
        upper=scalar(self.parts['R70']['value']);lower=scalar(self.parts['R71']['value'])
        # Accept a declared tolerance, or explicit Yageo RC-F (1%) / RT-B (0.1%) MPN.
        def tolerance(p):
            if 'tolerance_percent' in p:return float(p['tolerance_percent'])/100
            if re.match(r'RC\d{4}FR',p['mpn']):return .01
            if re.match(r'RT\d{4}BR',p['mpn']):return .001
            raise AssertionError('Declare verified tolerance for '+p['ref']+' '+p['mpn'])
        tu,tl=tolerance(self.parts['R70']),tolerance(self.parts['R71'])
        vnom=.6*(1+upper/lower)
        vmin=.588*(1+upper*(1-tu)/(lower*(1+tl)))
        vmax=.612*(1+upper*(1+tu)/(lower*(1-tl)))
        release_max=3.08*1.02*1.015
        rlim=scalar(self.parts['R72']['value'])/1000
        tr=tolerance(self.parts['R72'])
        imin=25230/(rlim*(1+tr))**1.016
        imax=22980/(rlim*(1-tr))**.94
        return {
            'buck':{'nominal_V':vnom,'static_min_V':vmin,'static_max_V':vmax,
                    'assumptions':'VFB 0.588..0.612 V; independent resistor tolerance extremes; excludes ripple, line/load transients and temperature effects not included in electrical table.'},
            'supervisor':{'assert_threshold_min_V':3.08*.98,'release_threshold_max_V':release_max,
                          'release_headroom_from_static_buck_min_mV':1000*(vmin-release_max),
                          'release_delay_ms':[130,200,270],
                          'assert_delay_max_us_test_condition':50,
                          'warning':'Does not guarantee reset before 3.0V on a fast collapse. Test the real rail ramp.'},
            'USB_current_limit_mA':[imin,imax],
            'watchdog_pullup_uA_at_3V3':3.3/scalar(self.parts['R11']['value'])*1e6,
            'encoder_passive_high_nominal_V':3.3*100/(100+10),
            'USB_endpoint_budget':{'CDC':3,'UAC_playback_feedback':2,'noncontrol_total':5,'noncontrol_limit':6,'IN_including_EP0':4,'IN_limit':5},
            'INA226_external_2mohm':{'15A_mV_W':[30,.45],'30A_mV_W':[60,1.8],'Current_LSB_A':.002,'CAL':1280,'Power_LSB_W':.05},
        }

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('netlist',type=Path)
    ap.add_argument('--circuit',type=Path)
    args=ap.parse_args()
    circuit_path=args.circuit or args.netlist.parent/'circuit.json'
    try:
        circuit=json.loads(circuit_path.read_text());root=ET.parse(args.netlist).getroot()
        r=Review(circuit,root)
        pins=r.compare_netlist();r.structural();logic=r.logic_tests();calc=r.calculations()
        margin=calc['supervisor']['release_headroom_from_static_buck_min_mV']
        warnings=[]
        if margin < 50:
            warnings.append(f'Only {margin:.2f} mV static buck-to-supervisor release margin before ripple/transients. Increase design margin; not a robust worst-case startup budget.')
        report={'status':'PASS','warnings':warnings,'physical_pin_assignments_compared':pins,'requirements':r.requirements,
                'logic':logic,'calculations':calc,
                'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (circuit_path,args.netlist)},
                'datasheet_model_sources':SOURCES,
                'unvalidated':['Physical behaviour under brownout and partial power','USB enumeration/suspend/current compliance','MCU firmware and host broker','Servo timing and cable load','Manufacturing, EMC/ESD and thermal performance']}
        print(json.dumps(report,indent=2))
        return 0
    except Exception as ex:
        print(json.dumps({'status':'FAIL','error':str(ex)},indent=2));return 1

if __name__=='__main__':sys.exit(main())
