"""Power/USB corrections for Core V1C; modifies only the supplied parts list.

Call after loading V1B parts, before layout. No file writes on import.
Device pin maps have been checked against manufacturer data sheets (see audit).
Reserved additions: U20, U22; R70..79; C40..45; D20..22; L1.
GPIO1 is intentionally untouched: logic audit owns its new feedback assignment.
"""
from copy import deepcopy
import uuid


def apply(parts):
    def uid(ref):
        return str(uuid.uuid5(uuid.NAMESPACE_URL, 'moss-core-v1c/' + ref))

    def put(ref, value, fp, group, pins, kind='ic', mpn=None, desc='', near=None):
        old = next((p for p in parts if p['ref'] == ref), None)
        p = dict(ref=ref, value=value, fp=fp, group=group,
                 pins={str(k): list(v) for k, v in pins.items()}, kind=kind,
                 mpn=mpn or value, desc=desc, near=near,
                 uuid=old['uuid'] if old else uid(ref))
        if old:
            parts[parts.index(old)] = p
        else:
            parts.append(p)
        return p

    def r(ref, val, a, b, group, near, code):
        return put(ref, val, 'Resistor_SMD:R_0603_1608Metric', group,
                   {1: ('1', a, 'passive'), 2: ('2', b, 'passive')}, 'R',
                   'RC0603FR-07' + code + 'L', near=near)

    def c(ref, val, a, b, group, near, mpn, size='0603_1608Metric'):
        return put(ref, val, 'Capacitor_SMD:C_' + size, group,
                   {1: ('1', a, 'passive'), 2: ('2', b, 'passive')}, 'C',
                   mpn, near=near)

    power = '01_USB_Power'
    drive = '04_Drive_Encoders'
    removed = {'F1', 'C3', 'C8', 'R59', 'R60', 'C28'}
    parts[:] = [p for p in parts if p['ref'] not in removed]
    by_ref = lambda: {p['ref']: p for p in parts}

    # USB power is the only board supply. Diode remains for immediate anti-return.
    p = by_ref()['D1']
    p['pins']['2'][1] = 'VBUS'
    p['desc'] = 'Pin1 cathode to V5_PRE, pin2 anode to VBUS. Immediate reverse-current blocking.'
    put('U2', 'TPD2E2U06DCKR', 'Package_TO_SOT_SMD:SOT-323_SC-70', power,
        {1: ('IO1', 'USB_P', 'passive'), 2: ('IO2', 'USB_N', 'passive'),
         3: ('GND', 'GND', 'power_in')},
        desc='Two-channel 1.5pF ESD. DCK: 1 IO1, 2 IO2, 3 GND. Place at USB connector, direct short GND vias.', near='J1')
    for ref, net in [('D20', 'CC1'), ('D21', 'CC2'), ('D22', 'VBUS')]:
        put(ref, 'TPD1E10B06DYAR', 'Diode_SMD:D_SOD-523', power,
            {1: ('IO', net, 'passive'), 2: ('GND', 'GND', 'passive')}, 'D',
            desc='Bidirectional ESD, 5.5V standoff. Pin reversal electrically equivalent. Not DC overvoltage protection.', near='J1')
    put('U3', 'TPS2553DBVR', 'Package_TO_SOT_SMD:SOT-23-6', power,
        {1: ('IN', 'V5_PRE', 'power_in'), 2: ('GND', 'GND', 'power_in'),
         3: ('EN', 'V5_PRE', 'input'), 4: ('FAULT_N', 'USB_PWR_FAULT_N', 'open_collector'),
         5: ('ILIM', 'USB_ILIM', 'passive'), 6: ('OUT', 'V5', 'power_out')},
        desc='60.4k 1% ILIM: calculated 387..491mA DC limit. This is not the pre-enumeration 100mA policy. Soft start; Schottky retained for immediate reverse blocking.', near='J1')
    r('R72', '60.4k', 'USB_ILIM', 'GND', power, 'U3', '60K4')
    r('R73', '47k', '3V3', 'USB_PWR_FAULT_N', power, 'U3', '47K')
    by_ref()['U1']['pins']['38'] = ['IO2', 'USB_PWR_FAULT_N', 'bidirectional']

    # Efficient 3.384V converter. Do not infer 2A USB capability from IC rating.
    put('U4', 'TLV62569DBVR', 'Package_TO_SOT_SMD:SOT-23-5', power,
        {1: ('EN', 'BUCK_EN', 'input'), 2: ('GND', 'GND', 'power_in'),
         3: ('SW', 'BUCK_SW', 'power_out'), 4: ('VIN', 'V5', 'power_in'),
         5: ('FB', 'BUCK_FB', 'input')},
        desc='3.384V nominal from 464k/100k 0.1%. 100k/100nF EN delay separates input-capacitor charge from buck soft start. Design budget 200mA typical / 350mA continuous at 3V3; RF disabled. IC rating2A is not USB power availability.', near='U3')
    put('L1', '2.2uH', 'Inductor_SMD:L_Coilcraft_XAL4020-XXX', power,
        {1: ('SW', 'BUCK_SW', 'passive'), 2: ('OUT', '3V3', 'passive')}, 'L',
        'XAL4020-222MEC',
        desc='2.2uH +/-20%, DCR max38.7mOhm, Isat typ5.6A (30% drop), Irms4A at20C rise. Selected from TI reference design family.', near='U4')
    r('R70', '464k', '3V3', 'BUCK_FB', power, 'U4', '464K')
    by_ref()['R70']['mpn'] = 'RT0603BRD07464KL'
    by_ref()['R70']['desc'] = 'Thin-film0.1%,25ppm/C; ratio tolerance is required for brownout release margin.'
    r('R71', '100k', 'BUCK_FB', 'GND', power, 'U4', '100K')
    by_ref()['R71']['mpn'] = 'RT0603BRD07100KL'
    by_ref()['R71']['desc'] = 'Thin-film0.1%,25ppm/C; ratio tolerance is required for brownout release margin.'
    r('R74', '100k', 'V5', 'BUCK_EN', power, 'U4', '100K')
    c('C42', '100nF', 'BUCK_EN', 'GND', power, 'U4', 'GRM188R71C104KA01D')
    c('C4', '4.7uF', 'V5', 'GND', power, 'U4', 'GRM21BR71A475KA73L', '0805_2012Metric')
    c('C40', '100nF', 'V5', 'GND', power, 'U4', 'GRM188R71C104KA01D')
    c('C5', '10uF', '3V3', 'GND', power, 'U4', 'GRM21BR71A106KA73L', '0805_2012Metric')
    c('C6', '10uF', '3V3', 'GND', '02_Controller', 'U1', 'GRM21BR71A106KA73L', '0805_2012Metric')
    by_ref()['C5']['desc'] = 'Local output capacitor. X7R10V; TI LC table allows nominal10uF with up to50% effective reduction. Not a measured DC-bias curve.'

    # Brownout supervision replaces the inaccurate EN RC-only reset.
    put('U20', 'TLV803EA30DBZR', 'Package_TO_SOT_SMD:SOT-23', '02_Controller',
        {1: ('GND', 'GND', 'power_in'), 2: ('RESET_N', 'RESET_N', 'open_collector'),
         3: ('VDD', '3V3', 'power_in')},
        desc='3.08V falling threshold, 200ms nominal delay, open drain. DBZ without R/V pinout modifier: 1GND 2RESET 3VDD. Pulls MCU reset and hardware clear chain low on undervoltage.', near='U1')
    c('C41', '100nF', '3V3', 'GND', '02_Controller', 'U20', 'GRM188R71C104KA01D')
    # Avoid >2.5mA through WD pullup alone in USB suspend.
    r('R11', '47k', '3V3', 'WD_OK', '03_Hardware_Interlock', 'U5', '47K')

    # Encoder power OFF before enumeration and during suspend. All pullups switch too.
    put('U22', 'TPS22918DBVR', 'Package_TO_SOT_SMD:SOT-23-6', drive,
        {1: ('VIN', '3V3', 'power_in'), 2: ('GND', 'GND', 'power_in'),
         3: ('ON', 'ENC_POWER_EN', 'input'), 4: ('CT', 'ENC_SLEW_CT', 'passive'),
         5: ('QOD', 'ENC_3V3', 'passive'), 6: ('VOUT', 'ENC_3V3', 'power_out')},
        desc='Encoder supply switch. GPIO42 default off; enable only after USB configuration. 10nF CT gives ~17.5ms 3.3V rise nominal. QOD direct: external load capacitance must remain below200uF.', near='J3')
    by_ref()['U1']['pins']['35'] = ['IO42', 'ENC_POWER_EN', 'bidirectional']
    r('R75', '47k', 'ENC_POWER_EN', 'GND', drive, 'U22', '47K')
    c('C43', '1uF', '3V3', 'GND', drive, 'U22', 'GRM188R61A105KA61D')
    c('C44', '1uF', 'ENC_3V3', 'GND', drive, 'U22', 'GRM188R61A105KA61D')
    c('C45', '10nF', 'ENC_SLEW_CT', 'GND', drive, 'U22', 'GRM188R71H103KA01D')
    for j in ('J3', 'J4'):
        by_ref()[j]['pins']['2'] = ['ENC_3V3', 'ENC_3V3', 'passive']
    filter_nets = ['EL_A_F', 'EL_B_F', 'ER_A_F', 'ER_B_F']
    for p in parts:
        if p['kind'] == 'R' and p['value'] == '10k':
            nets = [pin[1] for pin in p['pins'].values()]
            if '3V3' in nets and any(n in nets for n in filter_nets):
                for pin in p['pins'].values():
                    if pin[1] == '3V3':
                        pin[1] = 'ENC_3V3'
    for i, net in enumerate(filter_nets, 76):
        r('R'+str(i), '100k', net, 'GND', drive, 'U12', '100K')
    assert len({p['ref'] for p in parts}) == len(parts), 'Reference collision'
    return parts
