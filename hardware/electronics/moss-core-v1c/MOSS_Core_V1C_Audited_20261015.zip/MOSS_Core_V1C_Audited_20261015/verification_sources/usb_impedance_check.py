"""Independent quasi-static odd-mode capacitance estimate; NumPy only.
Finite-volume divergence(eps grad V)=0 with grounded bottom and odd symmetry x=0.
Right conductor at +1 V; negative conductor represented by odd symmetry.
Codd=charge/+1V, solve twice (dielectric and all vacuum), Zdiff=2/c/sqrt(Codd*Codd0).
Rectangular finished copper, no coplanar ground pour, no vias/bends/pads.
"""
import numpy as np, math, time, json
from pathlib import Path
EPS0=8.8541878128e-12; C=299792458.

def solve(dx=.005, w=.15,s=.15,h=.0994,t=.035,er=4.1,mask=True,vacuum=False,extent=1.0,mask_top=.015,mask_sub=.030,mask_er=3.8):
    nx=ny=int(round(extent/dx));dx=extent/nx
    x=(np.arange(nx)+.5)*dx;y=(np.arange(ny)+.5)*dx
    X,Y=np.meshgrid(x,y)
    metal=(X>=s/2)&(X<s/2+w)&(Y>=h)&(Y<h+t)
    eps=np.where(Y<h,er,1.)
    if mask:
        # 30um over substrate,15um above copper. Includes conformal sidewall coat.
        in_cover=(Y>=h)&(Y<h+mask_sub)
        topcoat=(X>=s/2-mask_top)&(X<s/2+w+mask_top)&(Y>=h)&(Y<h+t+mask_top)
        eps=np.where(in_cover|topcoat,mask_er,eps)
    if vacuum:eps[:]=1
    def face(a,b,ma,mb):
        out=2*a*b/(a+b)
        return np.where(ma,b,np.where(mb,a,out))
    ex=face(eps[:,:-1],eps[:,1:],metal[:,:-1],metal[:,1:])
    ey=face(eps[:-1,:],eps[1:,:],metal[:-1,:],metal[1:,:])
    diag=np.zeros_like(eps)
    diag[:,:-1]+=ex;diag[:,1:]+=ex;diag[:-1,:]+=ey;diag[1:,:]+=ey
    # Domain boundaries at half-cell distance: Dirichlet ground.
    diag[:,0]+=2*eps[:,0];diag[:,-1]+=2*eps[:,-1]
    diag[0,:]+=2*eps[0,:];diag[-1,:]+=2*eps[-1,:]
    rhs=np.zeros_like(eps)
    rhs[:,:-1]+=ex*metal[:,1:];rhs[:,1:]+=ex*metal[:,:-1]
    rhs[:-1,:]+=ey*metal[1:,:];rhs[1:,:]+=ey*metal[:-1,:]
    rhs[metal]=0
    ex=ex*((~metal[:,:-1])&(~metal[:,1:]))
    ey=ey*((~metal[:-1,:])&(~metal[1:,:]))
    diag[metal]=1.
    def A(v):
        out=diag*v
        out[:,:-1]-=ex*v[:,1:];out[:,1:]-=ex*v[:,:-1]
        out[:-1,:]-=ey*v[1:,:];out[1:,:]-=ey*v[:-1,:]
        return out
    v=np.zeros_like(eps);r=rhs.copy();z=r/diag;p=z.copy();rz=np.sum(r*z)
    rnorm0=np.linalg.norm(rhs);start=time.time()
    for i in range(5000):
        ap=A(p);alpha=rz/np.sum(p*ap);v+=alpha*p;r-=alpha*ap
        if i%25==0 and np.linalg.norm(r)<rnorm0*1e-9:break
        z=r/diag;newrz=np.sum(r*z);p=z+(newrz/rz)*p;rz=newrz
    v[metal]=1.
    # Recompute dielectric conductances for flux through all conductor edges.
    ex=face(eps[:,:-1],eps[:,1:],metal[:,:-1],metal[:,1:])
    ey=face(eps[:-1,:],eps[1:,:],metal[:-1,:],metal[1:,:])
    q=np.sum(ex*np.abs(v[:,1:]-v[:,:-1])*(metal[:,1:]^metal[:,:-1]))
    q+=np.sum(ey*np.abs(v[1:,:]-v[:-1,:])*(metal[1:,:]^metal[:-1,:]))
    return dict(C_odd_F_m=float(q*EPS0),iterations=i+1,seconds=time.time()-start,
                grid_mm=dx,nx=nx,ny=ny,conductor_cells=int(metal.sum()),residual=float(np.linalg.norm(r)/rnorm0))

def impedance(dx,mask,**kw):
    a=solve(dx=dx,mask=mask,**kw);b=solve(dx=dx,mask=False,vacuum=True,**kw)
    return dict(parameters=dict(dx=dx,mask=mask,**kw),dielectric=a,vacuum=b,
                Zdiff_ohm=2/(C*math.sqrt(a['C_odd_F_m']*b['C_odd_F_m'])))

if __name__=='__main__':
    rows=[]
    for dx,mask in [(.005,False),(.005,True),(.0025,False),(.0025,True)]:
        r=impedance(dx,mask);rows.append(r);print(json.dumps(r),flush=True)
        Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2))
