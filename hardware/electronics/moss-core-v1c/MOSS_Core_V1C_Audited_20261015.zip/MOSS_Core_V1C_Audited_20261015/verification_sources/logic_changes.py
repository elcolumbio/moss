"""Evidence-based V1C logic changes. Pure transform; never writes the live design.

Inputs are the circuit.py PARTS list (or reviews/circuit.json['parts']).
Power-chain, current-sense, analogue AMP_5V detection and mechanics are owned
by separate reviews; no changes to those are made here.
"""
from copy import deepcopy
import uuid

SOURCES = {
    'hcs21': 'https://www.ti.com/lit/ds/symlink/sn74hcs21.pdf',
    'lvc17': 'https://www.ti.com/lit/ds/symlink/sn74lvc1g17.pdf',
    'lvc126': 'https://www.ti.com/lit/ds/symlink/sn74lvc1g126.pdf',
    'servo_adapter': 'https://files.waveshare.com/wiki/Bus-Servo-Adapter-(A)/Bus%20Servo%20Adapter%20(A)-Sch.pdf',
    'max98357': 'https://www.analog.com/media/en/technical-documentation/data-sheets/MAX98357A-MAX98357B.pdf',
}

REMOVED_REFS = {'U7', 'U8', 'C14', 'C15', 'Q1', 'R45', 'R46', 'R47'}

def apply(parts):
    parts = deepcopy(parts)
    refs = {p['ref']: p for p in parts}
    assert len(refs) == len(parts)
    assert all(r in refs for r in REMOVED_REFS | {'U6', 'U18', 'U14', 'C25', 'R48', 'R53'})

    def replace_ic(ref, value, footprint, pins, description):
        p = refs[ref]
        p.update(value=value, mpn=value, fp=footprint, desc=description,
                 pins={str(k): list(v) for k, v in pins.items()})
        # Derived data must be regenerated from the replacement, not inherited.
        for key in ('fp_local', 'sym', 'symbol_points', 'symbol_size'):
            p.pop(key, None)

    # Gate 1 directly combines all four healthy conditions. Gate 2 provides a
    # clean diagnostic for NC_FILTER. The external FAULT signal is still
    # conditioned by an overvoltage-tolerant LVC Schmitt buffer before HCS.
    replace_ic('U6', 'SN74HCS21PWR', 'Package_SO:TSSOP-14_4.4x5mm_P0.65mm', {
        1: ('1A', 'WD_OK', 'input'),
        2: ('1B', 'NC_FILTER', 'input'),
        3: ('NC', None, 'no_connect'),
        4: ('1C', 'POWER_FAULT_N', 'input'),
        5: ('1D', 'RESET_N', 'input'),
        6: ('1Y', 'SAFE_CLR_N', 'output'),
        7: ('GND', 'GND', 'power_in'),
        8: ('2Y', 'INTERLOCK_OK', 'output'),
        9: ('2A', 'NC_FILTER', 'input'),
        10: ('2B', '3V3', 'input'),
        11: ('NC', None, 'no_connect'),
        12: ('2C', '3V3', 'input'),
        13: ('2D', '3V3', 'input'),
        14: ('VCC', '3V3', 'power_in'),
    }, 'Dual four-input Schmitt AND: hardware healthy condition and NC diagnostic. '
       'FAULT must enter through U18; HCS inputs are not 5 V tolerant on 3V3. '
       'Does not replace power supervision or actuator power disconnection.')
    replace_ic('U18', 'SN74LVC1G17DCKR', 'Package_TO_SOT_SMD:SOT-353_SC-70-5', {
        1: ('NC', None, 'no_connect'),
        2: ('A', 'FAULT_FILTER_N', 'input'),
        3: ('GND', 'GND', 'power_in'),
        4: ('Y', 'POWER_FAULT_N', 'output'),
        5: ('VCC', '3V3', 'power_in'),
    }, '5.5 V-tolerant Schmitt fault receiver; conditions J9 before HCS logic. '
       'Default pull-up means a disconnected optional fault source is not detected.')

    # The rover BOM explicitly uses Waveshare Bus Servo Adapter (A), whose
    # DATA transmitter uses LVC logic at 3V3. Active-high OE directly matches
    # our hardware SERVO_OE_ON permission, eliminating the NPN inverter and
    # its 5 V pull-up. Buffer is disabled by the existing R44 pulldown.
    replace_ic('U14', 'SN74LVC1G126DCKR', 'Package_TO_SOT_SMD:SOT-353_SC-70-5', {
        1: ('OE', 'SERVO_OE_ON', 'input'),
        2: ('A', 'SERVO_TX', 'input'),
        3: ('GND', 'GND', 'power_in'),
        4: ('Y', 'SERVO_TX_BUF', 'tri_state'),
        5: ('VCC', '3V3', 'power_in'),
    }, '3V3 bus transmitter consistent with the installed Waveshare adapter. '
       'Active-high OE; Ioff and 5.5 V IOZ specified by TI. Release only after '
       'UART TX_DONE. Validate with actual ST3215/CF35 chain and harness.')
    refs['C25']['pins']['1'][1] = '3V3'
    refs['R48']['pins']['1'][1] = 'SERVO_TX_BUF'

    # SD_MODE unlike BCLK/LRCLK/DIN is limited to VDD+0.3 V. ADI explicitly
    # recommends ~2k series resistance when its supply can be below 3.3 V.
    refs['R53'].update(value='2.2k', mpn='RC0402FR-072K2L',
                      desc='Limits SD_MODE clamp current during amplifier power ramps; '
                           'ADI MAX98357A recommends approximately 2k for VDD < VDDIO.')

    def resistor(ref, value, mpn, a, b, group, near, description):
        assert ref not in refs
        p = dict(ref=ref, value=value, mpn=mpn,
                 fp='Resistor_SMD:R_0402_1005Metric', group=group,
                 pins={'1': ['1', a, 'passive'], '2': ['2', b, 'passive']},
                 kind='R', near=near, desc=description,
                 uuid=str(uuid.uuid5(uuid.NAMESPACE_URL, 'moss-core-v1c/'+ref)))
        parts.append(p); refs[ref] = p

    # Buffered I2S inputs otherwise float while ESP GPIOs are inputs at boot.
    for ref, net in [('R90', 'AUDIO_BCLK'), ('R91', 'AUDIO_LRCLK'), ('R92', 'AUDIO_DATA')]:
        resistor(ref, '47k', 'RC0402FR-0747KL', net, 'GND', '06_Audio', 'U16',
                 'Defined low I2S input while MCU is reset or unconfigured.')
    resistor('R93', '47k', 'RC0402FR-0747KL', 'SERVO_TX', '3V3', '05_Servo', 'U14',
             'UART idle high on MCU side; does not pull the external servo bus when TX is disabled.')

    # Observe actual hardware latch states after a transient fault. An MCU
    # stalled across the watchdog pulse cannot reconstruct these from WD_OK
    # after it has recovered. GPIO44 is ROM UART RX (input); GPIO43 must NOT
    # be used because the ROM drives its TX output. USB ROM + BOOT/RESET stay
    # the programming path, and TX0 remains available for one-way diagnostics.
    assert refs['U1']['pins']['36'][0] == 'IO44'
    assert refs['U1']['pins']['39'][0] == 'IO1'
    refs['U1']['pins']['36'] = ['IO44/DRIVE_ARMED_READ', 'ARMED_DRIVE', 'input']
    refs['U1']['pins']['39'] = ['IO1/ACT_ARMED_READ', 'ARMED_ACT', 'input']
    refs['TP4'].update(value='ACT_ARMED', desc='Actual actuator hardware latch output, not a software request.')
    refs['TP4']['pins']['1'] = ['ACT_ARMED', 'ARMED_ACT', 'passive']
    # AMP_5V's old MCU ADC divider is removed by power_changes.py. Keep that
    # removal in its owner, but ensure this transform does not leave DEBUG_RX.

    result = [p for p in parts if p['ref'] not in REMOVED_REFS]
    assert len(result) == len(parts) - len(REMOVED_REFS)
    names = {v[1] for p in result for v in p['pins'].values() if v[1]}
    assert not names.intersection({'HEALTH_OK', 'RESET_CLEAN_N', 'TX_BASE', 'SERVO_OE_N', 'SERVO_TX_5V'})
    assert refs['U6']['pins']['6'][1] == 'SAFE_CLR_N'
    assert refs['U14']['pins']['1'][1] == 'SERVO_OE_ON'
    assert refs['U14']['pins']['5'][1] == '3V3'
    assert 'DEBUG_RX' not in names
    return result

if __name__ == '__main__':
    import json
    from pathlib import Path
    original = json.loads(Path('/Users/macbookair/Downloads/MOSS_Core_V1B_Prototype_20261015/reviews/circuit.json').read_text())['parts']
    revised = apply(original)
    print(f'Logic transform: {len(original)} -> {len(revised)} parts; no design files written.')
